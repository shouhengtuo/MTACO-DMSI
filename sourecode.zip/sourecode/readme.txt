main program
%% -----------main_for_DME.m  : the main program for DME models
%%------------main_for_NDME.m : the main program for NDME models
%%------------MTACO.m : the search program of MTACO-DMSI in the 1st stage.
%%------------Serach.m : the population  serach program based on ACO
%%------------Transfer2.m : The Knowledge transfer program .
%%------------updatePheromones2.m : The pheromones update program

%%  The score functions for evaluating the association
  ------------K2_score.m  : Bayesian network-based K2-score .
  ------------JS_score.m  : Jensen–Shannon divergence-based JS-score.
  ------------Gtest_score.m : the G-test function 